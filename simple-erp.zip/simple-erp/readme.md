# install

1. install *python 3.6.x*


# questions

1. use existed username & passwd.