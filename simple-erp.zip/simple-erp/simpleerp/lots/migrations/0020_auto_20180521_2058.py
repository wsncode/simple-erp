# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0019_auto_20180505_2103'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 21, 20, 58, 57, 358046)),
        ),
        migrations.AlterField(
            model_name='lots',
            name='status',
            field=models.CharField(max_length=10, choices=[('in', 'In stock'), ('out', 'Out'), ('scrapped', 'Scrapped'), ('submit', 'Submit for scrap'), ('pending', 'Pending for scrap'), ('consumed', 'Lot consumed')]),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 21, 20, 58, 57, 359026)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 21, 20, 58, 57, 359026)),
        ),
    ]
