# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0011_auto_20171217_1706'),
    ]

    operations = [
        migrations.AddField(
            model_name='msg',
            name='receiv_role',
            field=models.CharField(max_length=10, blank=True, null=True),
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 31, 31, 96610)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 31, 31, 98115)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 31, 31, 97614)),
        ),
    ]
