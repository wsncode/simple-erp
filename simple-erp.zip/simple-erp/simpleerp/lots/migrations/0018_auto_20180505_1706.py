# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0017_auto_20180416_2218'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 17, 6, 5, 439498)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 17, 6, 5, 439498)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='status',
            field=models.CharField(max_length=10, choices=[('mctodo', 'MC todo'), ('managertodo', 'Manager todo'), ('done', 'Done'), ('info', 'Info')]),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 17, 6, 5, 439498)),
        ),
    ]
