# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0004_auto_20171126_2040'),
    ]

    operations = [
        migrations.AddField(
            model_name='msg',
            name='new_lot',
            field=models.ForeignKey(blank=True, null=True, related_name='msg_new_lot', to='lots.Lots'),
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 42, 59, 195753)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 42, 59, 197258)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 42, 59, 196757)),
        ),
    ]
