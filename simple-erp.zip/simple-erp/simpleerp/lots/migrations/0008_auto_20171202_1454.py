# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0007_auto_20171202_1451'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 54, 44, 801432)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 54, 44, 802434)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 54, 44, 802434)),
        ),
        migrations.AlterField(
            model_name='record',
            name='purpose',
            field=models.CharField(max_length=100, default='NA'),
        ),
    ]
