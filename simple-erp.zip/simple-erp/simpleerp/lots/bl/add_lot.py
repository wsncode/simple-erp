from datetime import datetime

from django.contrib.auth.models import User
from django.db import transaction

from ..models import Lots, Record

def add_one_lot(lot_info, user):
    eng_eid = lot_info.get("eng_eid")
    try:
        pe = User.objects.get(username=lot_info.get("PE"))
    except Exception:
        return "FAILED! PE name not right,please check."

    if len(Lots.objects.filter(eng_eid=eng_eid)):
        return "FAILED! Lot number should be unique."
    if lot_info.get("LPN"):
        LPN = lot_info.get("LPN").upper()
    else:
        return "FAILED! Please fill all blank."
    if lot_info.get("part_number"):
        part_number = lot_info.get("part_number").upper()
    else:
        return "FAILED! Part Number can not blank."
    if lot_info.get("package"):
        package = lot_info.get("package").upper()
    else:
        return "FAILED! Package Description can not blank."
    if lot_info.get("qty"):
        qty = int(lot_info.get("qty"))
        if str(qty).isdigit():
            qty = int(qty)
        else:
            return "FAILED! QTY should be number."
    else:
        return "FAILED! QTY can not blank."
    if lot_info.get("purpose"):
        purpose = lot_info.get("purpose")
    else:
        return "FAILED! Engineering Purpose can not blank."
    if lot_info.get("shelf_number"):
        shelf_number = lot_info.get("shelf_number")
    else:
        return "FAILED! Shelf Description can not blank."
    if lot_info.get("shelf_code"):
        shelf_code = lot_info.get("shelf_code").upper()
    else:
        return "FAILED! Shelf Code can not blanks."
    if lot_info.get("source"):
        source = lot_info.get("source").upper()
    else:
        return "FAILED! RKS/ENG can not blank."
    if lot_info.get("box_number"):
        box_number = int(lot_info.get("box_number"))
        if str(box_number).isdigit():
            box_number = int(box_number)
        else:
            return "FAILED! Box QTY should be number."
    else:
        return "FAILED! Box QTY can not blank."
    if lot_info.get("tracecode"):
        tracecode = lot_info.get("tracecode").upper()
    else:
        return "FAILED! Trace Code can not blank."

    with transaction.atomic():
        lots = Lots(
            mfg_eid=lot_info.get("mfg_eid").upper(),
            eng_eid=eng_eid,
            LPN=LPN,
            part_number=part_number,
            package=package,
            tracecode=tracecode,
            qty=qty,
            purpose=purpose,
            shelf_number=shelf_number,
            shelf_code=shelf_code,
            box_number=box_number,
            source=source,
            PE=pe,
            manager=pe.member.manager,
            date=datetime.now(),
            status="in",
        )
        lots.save()

        lot = Lots.objects.get(eng_eid=eng_eid)
        record = Record(
            lots=lot,
            package=lot_info.get("package"),
            qty=lot_info.get("qty"),
            comment="NA",
            PE=pe,  # Requestor
            MC=user,  # Operator
            date=datetime.now(),
            op="new",
        )
        record.save()

        return "OK"

def get_lotid(lotid):
    id = int(lotid[-6:])
    id = int(id)
    print(id)
    id = id + 1
    if id < 10:
        idstr = str(id)
        idstr = "00000" + idstr
    elif id < 100:
        idstr = str(id)
        idstr = "0000" + idstr
    elif id < 1000:
        idstr = str(id)
        idstr = "000" + idstr
    elif id < 10000:
        idstr = str(id)
        idstr = "00" + idstr
    elif id < 100000:
        idstr = str(id)
        idstr = "0" + idstr
    elif id < 1000000:
        idstr = str(id)
    else:
        idstr = "-1"
    return idstr

def gen_ENGID(username):
    mc2engid = {"mc0": "ENGA", "mc1": "ENGB", "mc2": "ENGC", "mc3": "ENGD", "mc4": "ENGG", "mc5": "ENGH", "mc6": "ENGJ",
                "mc7": "ENGR", "mc8": "ENGV","mca1": "ASSC","mca2": "ASSI","mca3": "ASSQ","mca4": "ASSJ","mca5": "ASSL",
                "mca6": "ASSM","mca7": "ASSX","mca8": "ASSP","mca9": "ASSH","mca10": "ASSN","mca11": "ASSW",
                "mca12": "ASSQ"}
    filter_dict = {}
    query = mc2engid.get(username)
    filter_dict["eng_eid" + "__contains"] = query
    lot = Lots.objects.filter(**filter_dict).order_by("-id")
    if lot:
        lotid = lot[0].eng_eid
        number = get_lotid(lotid)
        if number == "-1":
            ENGID = "error"
        else:
            ENGID = query + number

    else:
        ENGID = query + "000001"

    return ENGID