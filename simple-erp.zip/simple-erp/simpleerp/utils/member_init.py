import os, datetime
from django.core.wsgi import get_wsgi_application
from django.db import transaction

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "simpleerp.settings")
application = get_wsgi_application()

from django.contrib.auth.models import User
from member.models import Member


def import_managers():
    with open("user.csv","r") as fp:
        for line in fp.readlines():
            line = line.split(";")
            if line[0] == "Manager":
                user = User(
                    username = line[1],

                )
                user.set_password(line[1])
                user.save()
                member = Member(
                    user = user,
                    name = line[3],
                    role = "manager",
                    Email = line[4]
                )
                member.save()

def import_PEs():
    with open("user.csv","r") as fp:
        for line in fp.readlines():
            line = line.replace("\n","").split(";")

            if line[0] == "PE":
                with transaction.atomic():
                    exist_member = Member.objects.filter(user__username = line[1])
                    if len(exist_member):
                        continue

                    user = User(
                        username = line[1],

                    )
                    user.set_password(line[1])

                    Member.manager.username = line[5]
                    print(Member.manager.username)
                    manager = Member.objects.get(name = line[5])
                    user.save()
                    member = Member(
                        user=user,
                        name=line[3],
                        role="pe",
                        manager= manager.user,
                        Email=line[4]
                    )
                    member.save()


#                Member.manager.username = line[5]

def import_MCs():
    with open("user.csv","r") as fp:
        for line in fp.readlines():
            line = line.split(";")
            if line[0] == "MC":
                with transaction.atomic():
                    user = User(
                        username = line[1],
                    )
                    user.set_password(line[1])
                    user.save()
                    member = Member(
                        user = user,
                        name = line[3],
                        role = "mc",
                        Email = line[4]
                    )
                    member.save()

def undo():
    users = User.objects.filter(date_joined__gt = (datetime.datetime.now()-datetime.timedelta(hours=261))).delete()

if __name__ == "__main__":
    #import_PEs()
    #import_managers()
    #undo()
   #import_MCs()
   import_MCs()