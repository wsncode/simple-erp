# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0005_auto_20171126_2042'),
    ]

    operations = [
        migrations.AddField(
            model_name='msg',
            name='message',
            field=models.CharField(max_length=100, default=' '),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 21, 16, 21, 838516)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 21, 16, 21, 840020)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 21, 16, 21, 839519)),
        ),
    ]
