# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0008_auto_20171202_1454'),
    ]

    operations = [
        migrations.AddField(
            model_name='lots',
            name='shelf_code',
            field=models.CharField(max_length=10, default='2M'),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 15, 17, 39, 341191)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 15, 17, 39, 343196)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 15, 17, 39, 342194)),
        ),
    ]
