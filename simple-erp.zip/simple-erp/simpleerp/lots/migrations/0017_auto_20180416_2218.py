# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0016_auto_20180402_2201'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 16, 22, 18, 34, 985921)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 16, 22, 18, 34, 987884)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='status',
            field=models.CharField(max_length=10, choices=[('todo', 'To do'), ('done', 'Done'), ('info', 'Info')]),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 16, 22, 18, 34, 986904)),
        ),
    ]
