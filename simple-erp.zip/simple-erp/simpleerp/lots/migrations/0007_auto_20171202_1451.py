# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0006_auto_20171126_2116'),
    ]

    operations = [
        migrations.AddField(
            model_name='record',
            name='package',
            field=models.CharField(max_length=100, default='NA'),
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 51, 23, 352696)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 51, 23, 355735)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 2, 14, 51, 23, 353729)),
        ),
    ]
