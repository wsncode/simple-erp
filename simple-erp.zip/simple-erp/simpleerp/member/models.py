# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import User

class Member(models.Model):
    ROLE_CHOICES = (
        (u'mc', u'MC'),
        (u'pe', u"PE"),
        (u"manager", u"manager"),
        (u"admin", u"admin")
    )
    user = models.OneToOneField(User, related_name="member")
    name = models.CharField(max_length=50)
    role = models.CharField(verbose_name="role", max_length=10, choices=ROLE_CHOICES, default="pe")
    manager = models.ForeignKey(User,related_name="manager", blank=True, null=True )
    Email = models.CharField(max_length=100)
