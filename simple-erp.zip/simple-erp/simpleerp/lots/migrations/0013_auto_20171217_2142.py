# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0012_auto_20171217_2131'),
    ]

    operations = [
        migrations.RenameField(
            model_name='msg',
            old_name='receiv_role',
            new_name='receive_role',
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 42, 2, 826672)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 42, 2, 828676)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 21, 42, 2, 827673)),
        ),
    ]
