# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0015_auto_20180121_2034'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 2, 22, 1, 54, 778421)),
        ),
        migrations.AlterField(
            model_name='lots',
            name='shelf_number',
            field=models.CharField(max_length=50),
        ),
        migrations.AlterField(
            model_name='lots',
            name='status',
            field=models.CharField(max_length=10, choices=[('in', 'In stock'), ('out', 'Out'), ('scrapped', 'Scrapped'), ('pending', 'Pending for scrap'), ('consumed', 'Lot consumed')]),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 2, 22, 1, 54, 779402)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 4, 2, 22, 1, 54, 778421)),
        ),
        migrations.AlterField(
            model_name='record',
            name='op',
            field=models.CharField(max_length=10, choices=[('take', 'Take'), ('return', 'Return'), ('split', 'Split'), ('merge', 'Merge'), ('new', 'New'), ('scrap', 'Scrapped'), ('pending', 'Pending scrap'), ('Stop', 'Scrap rejected')]),
        ),
    ]
