# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0010_auto_20171202_1525'),
    ]

    operations = [
        migrations.AddField(
            model_name='msg',
            name='step',
            field=models.IntegerField(default=0),
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 17, 6, 8, 901029)),
        ),
        migrations.AlterField(
            model_name='lots',
            name='package',
            field=models.CharField(max_length=50),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 17, 6, 8, 902058)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='message',
            field=models.CharField(max_length=100, blank=True, null=True),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 17, 17, 6, 8, 901029)),
        ),
    ]
