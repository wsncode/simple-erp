# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0018_auto_20180505_1706'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 21, 3, 30, 898376)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 21, 3, 30, 898376)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2018, 5, 5, 21, 3, 30, 898376)),
        ),
        migrations.AlterField(
            model_name='record',
            name='op',
            field=models.CharField(max_length=10, choices=[('take', 'Take'), ('edit', 'Edit'), ('return', 'Return'), ('split', 'Split'), ('merge', 'Merge'), ('new', 'New'), ('scrap', 'Material Scrapped'), ('submit', 'Submit for scrap'), ('approve', 'Scrap approved'), ('Stop', 'Scrap rejected')]),
        ),
    ]
