# -*- coding: utf-8 -*-

from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

class Lots(models.Model):
    STATUS_CHOICES = (
        (u'in', u'In stock'),
        (u'out', u"Out"),
        (u'scrapped', u"Scrapped"),
        (u'submit', u"Submit for scrap"),
        (u'pending', u"Pending for scrap"),
        (u'consumed', u"Lot consumed")
    )
    mfg_eid = models.CharField(max_length=50, blank=True, null=True)
    eng_eid = models.CharField(max_length=50)
    LPN = models.CharField(max_length=50)
    part_number = models.CharField(max_length=50)
    package = models.CharField(max_length=50)
    tracecode = models.CharField(max_length=50, blank=True, null=True)
    qty = models.IntegerField()
    purpose = models.CharField(max_length=100)
    shelf_number = models.CharField(max_length=50)
    shelf_code = models.CharField(max_length=10)
    box_number = models.CharField(max_length=10)
    source = models.CharField(max_length=10)
    date = models.DateTimeField(default=datetime.now())
    PE = models.ForeignKey(User, related_name="current_PE")
    manager = models.ForeignKey(User)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES)

    def  __str__(self):
        return self.eng_eid


class Record(models.Model):
    OP_CHOICES = (
        ("take","Take",),
        ("edit", "Edit"),
        ("return","Return"),
        ("split","Split"),
        ("merge","Merge"),
        ("new","New"),
        ("scrap", "Material Scrapped"),
        ("submit", "Submit for scrap"),
        ("approve", "Scrap approved"),
        ("Stop", "Scrap rejected"),
    )
    lots = models.ForeignKey(Lots)
    qty = models.IntegerField()
    comment = models.CharField(max_length=100)
    date = models.DateTimeField(default=datetime.now())
    PE = models.ForeignKey(User)
    MC = models.ForeignKey(User, related_name="MC")
    op = models.CharField(max_length=10, choices=OP_CHOICES)
    purpose = models.CharField(max_length=100,default="NA")
    package = models.CharField(max_length=100, default="NA")

    def __str__(self):
        return self.PE.member.name +"/"+ self.op

class Msg(models.Model):
    OP_CHOICES = (
        ("take", "take",),
        ("return", "return"),
        ("scrap", "scrap"),
        ("split", "split"),
        ("merge", "merge"),
        ("new", "new"),
    )
    STATUS_CHOICES = (
        ("mctodo", "MC todo"),
        ("managertodo", "Manager todo"),
        ("done", "Done"),
        ("info", "Info"),
    )
    sender = models.ForeignKey(User, related_name="msg_sender")
    receiver = models.ForeignKey(User, related_name="msg_receiver", blank=True, null=True)
    receive_role = models.CharField(max_length=10, blank=True, null=True)
    date = models.DateTimeField(default=datetime.now())
    lot = models.ForeignKey(Lots)
    step = models.IntegerField(default=0)
    message = models.CharField(max_length=100, blank=True, null=True)
    new_lot = models.ForeignKey(Lots, related_name="msg_new_lot", blank=True, null=True)
    op = models.CharField(max_length=10)
    status = models.CharField(max_length=10,choices=STATUS_CHOICES)

    def __str__(self):
        return "{}/{}/{}".format(self.id, self.op, self.status)