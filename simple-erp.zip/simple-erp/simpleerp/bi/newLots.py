import datetime, sys, os
import xlwt

from django.core.wsgi import get_wsgi_application
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "simpleerp.settings")
application = get_wsgi_application()

from lots.models import Lots, Record



def makeReport(days):

    xfile = xlwt.Workbook()
    tabelename = xfile.add_sheet("Lots")
    tabelename.write(0, 0, 'Status')
    tabelename.write(0, 1, 'Lot number')
    tabelename.write(0, 2, 'MFG Lot number')
    tabelename.write(0, 3, 'LPN')
    tabelename.write(0, 4, 'Part Number')
    tabelename.write(0, 5, 'Package Description')
    tabelename.write(0, 6, 'Tracecode')
    tabelename.write(0, 7, 'INY QTY')
    tabelename.write(0, 8, 'Engineering Purpose')
    tabelename.write(0, 9, 'Box QTY')
    tabelename.write(0, 10, 'RKS/ENG')
    tabelename.write(0, 11, 'Storage Loc Description')
    tabelename.write(0, 12, 'Storage Loc code')
    tabelename.write(0, 13, 'PE Name')
    tabelename.write(0, 14, 'PE Manager')
    tabelename.write(0, 15, 'Last Updated Time Date')
    excel_row = 1

    new_records = Record.objects.filter(op = "new", date__gte=datetime.datetime.now()-datetime.timedelta(days=days), comment="NA")
    lots_id = new_records.values_list("lots")
    for lot_id in lots_id:
        lot = Lots.objects.get(id=lot_id[0])
        records = Record.objects.filter(lots=lot,op = "new",comment="NA")
        for record in records:
            lot_qty = record.qty
        lot_engeid = lot.eng_eid
        lot_mfgid = lot.mfg_eid
        lot_LPN = lot.LPN
        lot_Part = lot.part_number
        lot_Package = lot.package
        lot_trace = lot.tracecode
        lot_purpose = lot.purpose
        lot_box = lot.box_number
        lot_source = lot.source
        lot_shelfnumber = lot.shelf_number
        lot_shelfcode = lot.shelf_code
        lot_pe = lot.PE.member.name
        lot_pm = lot.manager.member.name
        lot_date = lot.date.strftime("%Y-%m-%d %H:%M:%S")
        lot_status = lot.get_status_display()
        tabelename.write(excel_row, 0, lot_status)
        tabelename.write(excel_row, 1, lot_engeid)
        tabelename.write(excel_row, 2, lot_mfgid)
        tabelename.write(excel_row, 3, lot_LPN)
        tabelename.write(excel_row, 4, lot_Part)
        tabelename.write(excel_row, 5, lot_Package)
        tabelename.write(excel_row, 6, lot_trace)
        tabelename.write(excel_row, 7, lot_qty)
        tabelename.write(excel_row, 8, lot_purpose)
        tabelename.write(excel_row, 9, lot_box)
        tabelename.write(excel_row, 10, lot_source)
        tabelename.write(excel_row, 11, lot_shelfnumber)
        tabelename.write(excel_row, 12, lot_shelfcode)
        tabelename.write(excel_row, 13, lot_pe)
        tabelename.write(excel_row, 14, lot_pm)
        tabelename.write(excel_row, 15, lot_date)

        excel_row += 1
    xfile.save('new_lot_list.xls')



if __name__ == "__main__":
    days = 34
    makeReport(days)