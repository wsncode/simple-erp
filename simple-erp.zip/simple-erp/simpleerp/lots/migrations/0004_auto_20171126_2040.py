# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0003_auto_20171126_2039'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 40, 44, 422993)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 40, 44, 424998)),
        ),
        migrations.AlterField(
            model_name='msg',
            name='receiver',
            field=models.ForeignKey(blank=True, null=True, related_name='msg_receiver', to=settings.AUTH_USER_MODEL),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 40, 44, 423995)),
        ),
    ]
