from django.shortcuts import render
from django.contrib.auth import authenticate
from django.http import HttpResponseRedirect, JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import User

import json

# Create your views here.
def index(request):
    if request.user.is_authenticated():
        return HttpResponseRedirect("/lots/")
    else:
        messages.warning(request, "Please login")
        return HttpResponseRedirect("/login")

@csrf_exempt
def ac(request):
    if request.method == "GET":
        result = User.objects.filter(member__role=request.GET.get("ac_type")).filter(member__name__contains = request.GET.get("search_str"))
        to_return = []
        for r in result:
            to_return.append({
                "value":r.username,
                "label": r"{}({})".format(r.member.name, r.username),
                "id":"123",
            })
        return JsonResponse(to_return, safe=False)

