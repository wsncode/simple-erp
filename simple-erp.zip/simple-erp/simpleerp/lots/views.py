from django.shortcuts import render
from .models import Lots, Record, Msg
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q
from datetime import datetime
import json
from django.core import serializers
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from django.contrib.auth.decorators import login_required
import xlwt, xlrd
from io import StringIO, BytesIO
from django.db import transaction

from .bl.add_lot import add_one_lot, gen_ENGID

# Create your views here.
def list(request):
    contain_query = ["eng_eid", "mfg_eid","LPN","part_number","package","tracecode","qty","purpose","shelf_number","shelf_code","box_number","source"]
    filter_dict = {}
    if len(request.GET):
        for query in contain_query:
            if request.GET.get(query):
                filter_dict[query+"__contains"] = request.GET.get(query)
    if request.GET.get("PE_id"):
        filter_dict["PE__username"] = request.GET.get("PE_id")
    if request.GET.get("PM_id"):
        filter_dict["manager__username"] = request.GET.get("PM_id")
    if request.GET.get("date"):
        filter_dict["date__startswith"] = datetime.strptime(request.GET.get("date").split(" ")[0], '%Y/%m/%d').date()
    if request.GET.get("status") and request.GET.get("status")!="all":
        filter_dict["status"] = request.GET.get("status")
    elif request.GET.get("status") == "all":
        pass
    else:
        filter_dict["status"] = "in"
    if filter_dict:
        lots = Lots.objects.filter(**filter_dict)
    else:
        lots = Lots.objects.all()
    lots = lots.order_by("-date")

   # paginator = Paginator(lots, 8, 1)
    serializers.serialize("json",lots)
   # page = request.GET.get('page')
   # try:
   #     lot_page = paginator.page(page)
   # except PageNotAnInteger:
   #     lot_page = paginator.page(1)
    #except EmptyPage:
   #     lot_page = paginator.page(paginator.num_pages)
   # return render(request, "lots/list.html", {"lots":lot_page})
    return render(request, "lots/list.html", locals())

@csrf_exempt
def lots_export_exl(request):
    contain_query = ["eng_eid", "mfg_eid", "LPN", "part_number", "package", "tracecode", "qty", "purpose",
                     "shelf_number", "shelf_code", "box_number", "source"]
    filter_dict = {}
    if len(request.GET):
        for query in contain_query:
            if request.GET.get(query):
                filter_dict[query + "__contains"] = request.GET.get(query)
    if request.GET.get("PE_id"):
        filter_dict["PE__username"] = request.GET.get("PE_id")
    if request.GET.get("PM_id"):
        filter_dict["manager__username"] = request.GET.get("PM_id")
    if request.GET.get("date"):
        filter_dict["date__startswith"] = datetime.strptime(request.GET.get("date").split(" ")[0], '%Y/%m/%d').date()
    if request.GET.get("status") and request.GET.get("status") != "all":
        filter_dict["status"] = request.GET.get("status")
    elif request.GET.get("status") == "all":
        pass
    else:
        filter_dict["status"] = "in"
    if filter_dict:
        lots = Lots.objects.filter(**filter_dict)
    else:
        lots = Lots.objects.all()
    lots = lots.order_by("-date")
    if lots:
        xfile = xlwt.Workbook()
        tabelename = xfile.add_sheet("Lots")
        tabelename.write(0, 0, 'Status')
        tabelename.write(0, 1, 'Lot number')
        tabelename.write(0, 2, 'MFG Lot number')
        tabelename.write(0, 3, 'LPN')
        tabelename.write(0, 4, 'Part Number')
        tabelename.write(0, 5, 'Package Description')
        tabelename.write(0, 6, 'Tracecode')
        tabelename.write(0, 7, 'INY QTY')
        tabelename.write(0, 8, 'Engineering Purpose')
        tabelename.write(0, 9, 'Box QTY')
        tabelename.write(0, 10, 'RKS/ENG')
        tabelename.write(0, 11, 'Storage Loc Description')
        tabelename.write(0, 12, 'Storage Loc code')
        tabelename.write(0, 13, 'PE Name')
        tabelename.write(0, 14, 'PE Manager')
        tabelename.write(0, 15, 'Last Updated Time Date')

        excel_row = 1
        for lot in lots:
            lot_engeid = lot.eng_eid
            lot_mfgid = lot.mfg_eid
            lot_LPN = lot.LPN
            lot_Part = lot.part_number
            lot_Package = lot.package
            lot_trace = lot.tracecode
            lot_qty = lot.qty
            lot_purpose = lot.purpose
            lot_box = lot.box_number
            lot_source =lot.source
            lot_shelfnumber = lot.shelf_number
            lot_shelfcode = lot.shelf_code
            lot_pe = lot.PE.member.name
            lot_pm = lot.manager.member.name
            lot_date = lot.date.strftime("%Y-%m-%d %H:%M:%S")
            lot_status = lot.get_status_display()
            tabelename.write(excel_row, 0, lot_status)
            tabelename.write(excel_row,1,lot_engeid)
            tabelename.write(excel_row, 2, lot_mfgid)
            tabelename.write(excel_row, 3, lot_LPN)
            tabelename.write(excel_row, 4, lot_Part)
            tabelename.write(excel_row, 5, lot_Package)
            tabelename.write(excel_row, 6, lot_trace)
            tabelename.write(excel_row, 7, lot_qty)
            tabelename.write(excel_row, 8, lot_purpose)
            tabelename.write(excel_row, 9, lot_box)
            tabelename.write(excel_row, 10, lot_source)
            tabelename.write(excel_row, 11, lot_shelfnumber)
            tabelename.write(excel_row, 12, lot_shelfcode)
            tabelename.write(excel_row, 13, lot_pe)
            tabelename.write(excel_row, 14, lot_pm)
            tabelename.write(excel_row, 15, lot_date)

            excel_row += 1

        buffer = BytesIO()
        xfile.save(buffer)

        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment; filename=Lots list.xls'
        response.write(buffer.getvalue())
        buffer.close()

        return response
    else:
        return HttpResponse("FAILED! No lot information.")


@login_required
def record(request, eng_eid):
    lot = Lots.objects.get(eng_eid = eng_eid)
    records = Record.objects.filter(lots = lot)
    return render(request, "lots/record.html", locals()

                  )
@csrf_exempt
def record_export_exl(request, eng_eid):
    lot = Lots.objects.get(eng_eid =eng_eid)
    records = Record.objects.filter(lots=lot)
    if records:
        xfile = xlwt.Workbook()
        tabelename = xfile.add_sheet(str(lot.eng_eid))
        tabelename.write(0, 0, 'Lot number')
        tabelename.write(0, 1, 'LPN')
        tabelename.write(0, 2, 'Part Number')
        tabelename.write(0, 3, 'Package Description')
        tabelename.write(0, 4, 'INY QTY')
        tabelename.write(0, 5, 'QTY Change Justification')
        tabelename.write(0, 6, 'Operation')
        tabelename.write(0, 7, 'Operator')
        tabelename.write(0, 8, 'Requestor')
        tabelename.write(0, 9, 'Date')
        excel_row = 1
        for record in records:
            record_Lot = record.lots.eng_eid
            record_LPN = record.lots.LPN
            record_Part = record.lots.part_number
            record_Package = record.lots.package
            record_qty = record.qty
            record_comment = record.comment
            record_operation = record.op
            record_pe = record.PE.member.name
            record_mc = record.MC.member.name
            record_date = record.date.strftime("%Y-%m-%d %H:%M:%S")
            tabelename.write(excel_row,0,record_Lot)
            tabelename.write(excel_row, 1, record_LPN)
            tabelename.write(excel_row, 2, record_Part)
            tabelename.write(excel_row, 3, record_Package)
            tabelename.write(excel_row, 4, record_qty)
            tabelename.write(excel_row, 5, record_comment)
            tabelename.write(excel_row, 6, record_operation)
            tabelename.write(excel_row, 7, record_pe)
            tabelename.write(excel_row, 8, record_mc)
            tabelename.write(excel_row, 9, record_date)

            excel_row +=1

        buffer = BytesIO()
        xfile.save(buffer)

        response = HttpResponse(content_type='application/ms-excel')
        response['Content-Disposition'] = 'attachment; filename=record_of_{}.xls'.format(eng_eid)
        response.write(buffer.getvalue())
        buffer.close()

        return response
    else:
        return HttpResponse("FAILED! No record information.")

@csrf_exempt
def merge(request):
    if request.method == "POST":
        if request.user.member.role == "mc":
            try:
                pe = User.objects.get(username = request.POST.get("pe_name"))
            except Exception:
                return HttpResponse("FAILED! Please choose Requestor from drop down list.")
            merged_lot = request.POST.get("merge_eng_eid").split(",")
            target_lot = request.POST.get("mergeto_eng_eid")
            if target_lot not in merged_lot:
                return HttpResponse("Merged to lot number“should be one from the source lots.")
            with transaction.atomic():
                merged_lot.remove(target_lot)

                Target_lot = Lots.objects.get(eng_eid = target_lot)
                Merged_lot = Lots.objects.filter(eng_eid__in=merged_lot)
                part_number = Target_lot.part_number

                merged_lot_qty = 0
                merged_lot_id = ""
                merged_lot_tracecode=[Target_lot.tracecode]
                if Target_lot.mfg_eid != "" and Target_lot.mfg_eid != "NA":
                    merged_lot_mfgeid = [Target_lot.mfg_eid]
                else:
                    merged_lot_mfgeid = []

                for L in Merged_lot:
                    if L.part_number != part_number:
                        return HttpResponse("Only same device can merge!!")
                    merged_lot_qty += L.qty
                    L.qty = 0
                    L.status ="consumed"
                    L.date = datetime.now()
                    merged_lot_id += "{},".format(L.eng_eid)
                    merged_lot_tracecode.append(L.tracecode)
                    if L.mfg_eid != "" and L.mfg_eid != "NA":
                        merged_lot_mfgeid.append(L.mfg_eid)
                    L.save()
                Target_lot.qty = Target_lot.qty + merged_lot_qty
                Target_lot.box_number = request.POST.get("box_number")
                Target_lot.shelf_number = request.POST.get("shelf_number")
                Target_lot.tracecode =  ",".join(set(merged_lot_tracecode))
                Target_lot.mfg_eid = ",".join(set(merged_lot_mfgeid))
                Target_lot.shelf_code = request.POST.get("shelf_code")
                Target_lot.date=datetime.now()
                Target_lot.save()

                record = Record(
                    lots=Target_lot,
                    qty=Target_lot.qty,
                    comment="Merged from {}.".format(merged_lot_id[:-1]),
                    PE=pe, #Requestor
                    MC=request.user, #Operator
                    op="merge",
                    date=datetime.now(),
                    purpose="NA",
                )
                record.save()
                for L in Merged_lot:
                    record = Record(
                        lots=L,
                        qty=L.qty,
                        comment="Merged to {}.".format(Target_lot.eng_eid),
                        PE=pe, #Requestor
                        MC=request.user,#Operator
                        op="merge",
                        date=datetime.now(),
                        purpose="NA",
                    )
                    record.save()
            return HttpResponse("OK")
        else:
            return HttpResponse("FAILED! only MC can merge.")


@csrf_exempt
def edit(request):
    if request.method == "POST":

        edit_lot = Lots.objects.get(eng_eid=request.POST.get("eng_eid"))
        requestor = edit_lot.PE.member.name
        if request.user.member.role == "pe":
            with transaction.atomic():
                edit_pe = User.objects.get(username=request.POST.get("pe_name"))
                if request.POST.get("pe_name"):
                    edit_lot.PE =edit_pe
                    edit_lot.manager = edit_pe.member.manager
                    edit_lot.date = datetime.now()
                    edit_lot.save()
                record = Record(
                    lots=edit_lot,
                    qty=edit_lot.qty,
                    comment="Edit lot PE name from {}.".format(requestor),
                    PE=request.user,  # Requestor
                    MC=request.user,  # Operator
                    op="edit",
                    date=datetime.now(),
                    purpose="NA",
                )
                record.save()
            return HttpResponse("OK")
        if request.user.member.role == "mc":
            with transaction.atomic():
                edit_lot.box_number = request.POST.get("box_number")
                edit_lot.shelf_number = request.POST.get("shelf_number")
                edit_lot.shelf_code = request.POST.get("shelf_code")
                edit_lot.date = datetime.now()
                edit_lot.save()
                record = Record(
                    lots=edit_lot,
                    qty=edit_lot.qty,
                    comment="Edit lot box QTY,shelf information.",
                    PE=request.user,  # Requestor
                    MC=request.user,  # Operator
                    op="edit",
                    date=datetime.now(),
                    purpose="NA",
                )
                record.save()
                return HttpResponse("OK")


@csrf_exempt
def split(request):
    if request.method == "POST":
        if request.user.member.role == "mc":

            lot = Lots.objects.get(eng_eid=request.POST.get("split_eng_eid"))
            split_qty = request.POST.get("split_qty")
            if int(split_qty) == 0:
                return HttpResponse("FAILED! Split QTY can't be 0.")
            try:
                pe = User.objects.get(username = request.POST.get("pe_name"))
            except Exception:
                return HttpResponse("FAILED! Please choose Requestor from drop down list.")
            if lot.status =="scrapped":
                return HttpResponse("FAILED! Already scrapped.")

            # cpy a instance and change infos
            with transaction.atomic():
                data = {}
                for f in lot._meta.fields:
                    if f.__class__.__name__ != 'AutoField':
                        data[f.name] = getattr(lot, f.name)
                    else:
                        data[f.name] = None

                new_lot = Lots(**data)
                new_lot.eng_eid = request.POST.get("split_new_eid")  # get ENGID just one split lot
                if len(Lots.objects.filter(eng_eid=new_lot.eng_eid)):
                    return HttpResponse("FAILED! Lot number should be unique.")
                new_lot.qty = split_qty
                new_lot.date = datetime.now()
                new_lot.shelf_code = request.POST.get("shelf_code")
                new_lot.shelf_number = request.POST.get("shelf_number")
                new_lot.box_number = request.POST.get("split_box")
                new_lot.purpose = request.POST.get("split_purpose")

                lot.qty = lot.qty - int(split_qty)
                if lot.qty == 0:
                    return HttpResponse("FAILED! Split QTY can't the same with original lot QTY.")
                if lot.qty < 0:
                    return HttpResponse("FAILED! Split QTY can't bigger than original lot QTY.")
                lot.date = datetime.now()
                lot.save()

                new_lot.save()

                record = Record(
                    lots = lot,
                    qty = lot.qty,
                    comment = "Split to lot {}.".format(new_lot.eng_eid),
                    PE = pe,#requestor
                    MC = request.user,#operator
                    op = "split",
                    date=datetime.now(),
                    purpose = "NA",
                )
                record.save()

                record = Record(
                    lots=new_lot,
                    qty=split_qty,
                    comment="Split from lot {}.".format(lot.eng_eid),
                    PE=pe,#requestor
                    MC=request.user,#operator
                    op="new",
                    date=datetime.now(),
                    purpose="NA",
                )
                record.save()
                return HttpResponse("OK")
        else:
            return HttpResponse("FAILED! only MC can split.")

@csrf_exempt
def lotreturn(request):
    if request.method == "POST":
        if request.user.member.role == "mc":
            lot = Lots.objects.get(eng_eid=request.POST.get("eng_eid"))
            try:
                pe = User.objects.get(username=request.POST.get("pe_name"))
            except Exception:
                return HttpResponse("FAILED! Please choose Requestor from drop down list.")
            if lot.status == "scrapped":
                return HttpResponse("FAILED! Already scrapped.")
            if request.POST.get("return_take_qty") == request.POST.get("return_qty"): # qty same, no justification
                if lot.status == "in":
                    return HttpResponse("Failed!! Already return.")
                else:
                    with transaction.atomic():
                        lot.date = datetime.now()
                        lot.shelf_code = request.POST.get("return_shelf_code")
                        lot.shelf_number = request.POST.get("return_shelf_number")
                        lot.status = "in"
                        lot.save()
                        record = Record(
                            lots=lot,
                            qty=request.POST.get("return_take_qty"),
                            comment="Return lot.",
                            PE=pe,#requestor
                            MC=request.user,#operator
                            op="return",
                            date=datetime.now(),
                            purpose="NA",
                        )
                        record.save()
                        return HttpResponse("OK")
            else:
                if lot.status == "in":
                    return HttpResponse("Failed!! Already return.")
                else:
                    return_type = request.POST.get("return_type").split("<}")
                    return_comment = request.POST.get("return_comment").split("<}")
                    return_comment_qty = request.POST.get("return_comment_qty").split("<}")
                    comment = ""
                    pemanager = pe.member.manager
                    take_qty = request.POST.get("return_take_qty")
                    return_qty = request.POST.get("return_qty")
                    for i in range(len(return_type)):
                        comment = comment + "{}:{}, QTY:{}. \r\n".format(
                            return_type[i],
                            return_comment[i],
                            return_comment_qty[i]
                        )
                    with transaction.atomic():
                        record = Record(
                            lots=lot,
                            qty = request.POST.get("return_qty"),
                            comment=comment,
                            PE=pe,#requestor
                            MC=request.user,#operator
                            op="return",
                            date=datetime.now(),
                            purpose="NA",
                        )
                        record.save()
                        lot.qty = request.POST.get("return_qty")
                        lot.shelf_code = request.POST.get("return_shelf_code")
                        lot.shelf_number = request.POST.get("return_shelf_number")
                        lot.date = datetime.now()
                        if int(lot.qty) == 0:
                            lot.status = "consumed"
                        else:
                            lot.status = "in"
                        lot.save()
                    content = "PE: " + pe.member.name + " return lot "+ lot.eng_eid + ",take QTY is "+ take_qty+ ",return QTY is " + return_qty + ", detail information please click http://econ.nxp.com/record/"+ str(lot.eng_eid) #fixme
                    send_mail(pemanager.member.Email, "PE return QTY not match take QTY", content)
                return HttpResponse("OK")
        else:
            return HttpResponse("ONLY MC can return!")


@csrf_exempt
def take(request):
    if request.method == "POST":
        if request.user.member.role == "mc":
            take_lot = request.POST.get("eng_eid").split(",")
            Take_lot = Lots.objects.filter(eng_eid__in=take_lot)
            try:
                pe = User.objects.get(username=request.POST.get("pe_name"))
            except Exception:
                return HttpResponse("FAILED! Please choose Requestor from drop down list.")
            for lot in Take_lot:
                if lot.status == "out":
                    return HttpResponse("FAILED! Already take.")
                elif lot.status == "submit":
                    return HttpResponse("FAILED! Submit for scrap.")
                elif lot.status == "pending":
                    return HttpResponse("FAILED! Pending for scrap.")
                elif lot.status == "consumed":
                    return HttpResponse("FAILED! Lot consumed.")
                elif lot.status =="scrapped":
                    return HttpResponse("FAILED! Already scrapped.")
                else:
                    with transaction.atomic():
                        lot.date = datetime.now()
                        lot.status = "out"
                        lot.save()
                        record = Record(
                            lots=lot,
                            qty=lot.qty,
                            comment="Take lot.",
                            PE=pe,#requestor
                            MC=request.user,#operator
                            op="take",
                            date=datetime.now(),
                            purpose="NA",
                        )
                        record.save()
            return HttpResponse("OK")
        else:
            return HttpResponse("FAILED! only MC can take.")

@csrf_exempt
def scrap_req(request):
    if request.method == "POST":
        if request.user.member.role == "pe":
            lot = Lots.objects.get(eng_eid=request.POST.get("eng_eid"))

            message = json.dumps({
                "lot_qty": lot.qty
            })
            if lot.status =="out":
                return HttpResponse("FAILED! Already take, please return first.")
            elif lot.status =="pending":
                return HttpResponse("FAILED! Already request to scrap.")
            elif lot.status =="scrapped":
                return HttpResponse("FAILED! Already scrapped.")
            else:
                # send message
                with transaction.atomic():
                    msg = Msg(
                        step=1,
                        sender=request.user,
                        receive_role="mc",
                        lot=lot,
                        message = message,
                        op="scrap",
                        date=datetime.now(),
                        status="mctodo",
                    )
                    msg.save()
                    content = "PE:" + request.user.member.name + "  ask to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(msg.id) #fixme
                    try:
                        send_mail("mc_group", "PE ask to scrap lot", content)
                    except Exception:
                        return HttpResponse("FAILED! Please check your network.")
                    lot.status = "submit"
                    lot.date = datetime.now()
                    lot.save()
                    record = Record(
                        lots=lot,
                        qty=lot.qty,
                        comment="Submit to scrap lot.",
                        PE=request.user,  # requestor
                        MC=request.user,  # operator
                        op="submit",
                        date=datetime.now(),
                        purpose="NA",
                    )
                    record.save()
                return HttpResponse("OK")
        else:
            return HttpResponse("FAILED! only PE can scrap")

@login_required
def msg_detail(request, msg_id):
    msg = Msg.objects.get(id= msg_id)
    init_record = Record.objects.filter(lots=msg.lot).order_by("id")[0]
    try:
        message = json.loads(msg.message)
    except json.decoder.JSONDecodeError:
        pass
    except TypeError:
        pass

    if msg.step == 1 and msg.op == "scrap":
        lot_qty = message.get("lot_qty")
        return render(request, "lots/msg_scrap_1.html", locals())
    if msg.step == 2 and msg.op == "scrap":
        actual_qty = message.get("actual_qty")
        pe = User.objects.get(id=message.get("pe"))
        lot_qty = message.get("lot_qty")
        return render(request, "lots/msg_scrap_2.html", locals())
    if msg.step == 3 and msg.op == "scrap":
        actual_qty = message.get("actual_qty")
        pe = User.objects.get(id=message.get("pe"))
        lot_qty = message.get("lot_qty")
        return render(request, "lots/msg_scrap_3.html", locals())
    if msg.step == 4 and msg.op == "scrap":
        return render(request, "lots/msg_scrap_4.html", locals())


@csrf_exempt
def msg_handle(request):
    if request.user.member.role == "pe":
        return HttpResponse("FAILED! PE can not handle this.")
    if request.user.member.role == "manager":
        return HttpResponse("FAILED! Manager can not handle this.")
    def get_case(init_qty, scrap_qty, actual_qty):
        if scrap_qty == actual_qty:
            if init_qty == scrap_qty or (init_qty-scrap_qty <= 1 and init_qty-scrap_qty > 0):
                return "case1"
            else:
                return "case2"
        else:
            return "case2"

    msg_id = request.POST.get("id")
    msg = Msg.objects.get(id=msg_id)
    init_record = Record.objects.filter(lots=msg.lot).order_by("id")[0]
    message = json.dumps({
        "pe": msg.sender.id,
        "actual_qty": request.POST.get("actual_qty"),
        "lot_qty": msg.lot.qty
    })
    if get_case(init_record.qty, msg.lot.qty, int(request.POST.get("actual_qty"))) == "case1":
        with transaction.atomic():
            next_msg = Msg(
                step=3,
                status="info",
                sender = request.user,
                receiver= msg.sender,
                message= message,
                lot = msg.lot,
                date=datetime.now(),
                op = msg.op
            )
            next_msg.save()

            content = "PE:"+msg.sender.member.name +"  ask to scrap lot:"+ msg.lot.eng_eid +" MC finished check QTY, will scrap later."
            send_mail(msg.sender.member.Email,"Scrap lot feedback",content)
            another_msg = Msg(
                step=3,
                status="mctodo",
                sender=request.user,
                receiver=request.user,
                message=message,
                lot = msg.lot,
                date=datetime.now(),
                op = msg.op
            )
            another_msg.save()
            content = "PE:" + msg.sender.member.name + "  ask to scrap lot:" + msg.lot.eng_eid + " MC finished check QTY, QTY noraml, OK to release. Detail information please click http://econ.nxp.com/msg/" + str(another_msg.id) #fixme
            send_mail(request.user.member.Email, "PE ask to scrap lot", content)

            msg.message = message
            msg.status = "done"
            msg.save()
    else: # in case2 send a msg. to manager.

        pemanager = msg.sender.member.manager #This will send email to requstor PE manager
        with transaction.atomic():
            next_msg = Msg(
                step=2,
                status="info",
                sender=request.user,
                receiver=msg.sender,
                message=message,
                lot=msg.lot,
                date=datetime.now(),
                op=msg.op
            )
            next_msg.save()
            content = "PE:" + msg.sender.member.name + "  ask to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(next_msg.id)  #fixme
            send_mail(msg.sender.member.Email, "PE ask to scrap lot need manager approve", content)
            another_msg = Msg(
                step=2,
                status="managertodo",
                sender=request.user,
                receiver=pemanager,
                message=message,
                lot=msg.lot,
                date=datetime.now(),
                op=msg.op
            )
            another_msg.save()
            content = "PE:" + msg.sender.member.name + "  ask to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(
                another_msg.id) #fixme
            send_mail(pemanager.member.Email, "PE ask to scrap lot", content)
            msg.message = message
            msg.status = "done"
            msg.save()

    return HttpResponse("OK")

@csrf_exempt
def pm_approve(request):
    if request.user.member.role == "pe":
        return HttpResponse("FAILED! PE can not handle this.")
    if request.user.member.role == "mc":
        return HttpResponse("FAILED! MC can not handle this.")
    msg_id = request.POST.get("id")
    msg = Msg.objects.get(id=msg_id)
    init_record = Record.objects.filter(lots=msg.lot).order_by("id")[0]
    pe = User.objects.get(id= json.loads(msg.message).get("pe"))
    actual_qty = json.loads(msg.message).get("actual_qty")
    with transaction.atomic():
        msg.status = "done"
        msg.save()
        next_msg = Msg(
            step=3,
            status="info",
            sender=request.user,
            receiver=pe,
            message=msg.message,
            lot=msg.lot,
            date=datetime.now(),
            op=msg.op
        )
        next_msg.save()
        content = "Manager:" + pe.member.manager.member.name + "  approve to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(next_msg.id) #fixme
        send_mail(pe.member.Email, "Manager approve to scrap lot", content)
        another_msg = Msg(
            step=3,
            status="mctodo",
            sender=request.user,
            receiver=msg.sender,
            message=msg.message,
            lot=msg.lot,
            date=datetime.now(),
            op=msg.op
        )
        another_msg.save()
        content = "Manager:" + pe.member.manager.member.name + "  approve to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(another_msg.id) #fixme
        send_mail(msg.sender.member.Email, "Manager approve to scrap lot", content)

        msg.lot.qty = int(actual_qty)
        msg.lot.status = "pending"
        msg.lot.date = datetime.now()
        msg.lot.save()
        record = Record(
            lots=msg.lot,
            qty=int(actual_qty),
            comment=request.POST.get("scrap_comment"),
            PE=request.user,#requestor
            MC=request.user,#operator
            op="approve",
            date=datetime.now(),
            purpose="NA",
        )
        record.save()
    return HttpResponse("OK")

@csrf_exempt
def pm_reject(request):
    if request.user.member.role == "pe":
        return HttpResponse("FAILED! PE can not handle this.")
    if request.user.member.role == "mc":
        return HttpResponse("FAILED! MC can not handle this.")
    msg_id = request.POST.get("id")
    msg = Msg.objects.get(id=msg_id)
    init_record = Record.objects.filter(lots=msg.lot).order_by("id")[0]
    pe = User.objects.get(id=json.loads(msg.message).get("pe"))
    with transaction.atomic():
        msg.status = "done"
        msg.save()
        next_msg = Msg(
            step=4,
            status="info",
            sender=request.user,
            receiver=pe,
            lot=msg.lot,
            date=datetime.now(),
            op=msg.op
        )
        next_msg.save()
        content = "Manager:" + pe.member.manager.member.name + "  reject to scrap lot:" + msg.lot.eng_eid + ",detail information please click http://econ.nxp.com/msg/" + str(next_msg.id) #fixme
        send_mail(pe.member.Email, "Manager reject to scrap lot", content)

        another_msg = Msg(
            step=4,
            status="info",
            sender=request.user,
            receiver=msg.sender,
            lot=msg.lot,
            date=datetime.now(),
            op=msg.op
        )
        another_msg.save()
        content = "Manager:" + pe.member.manager.member.name + "  reject to scrap lot:" + msg.lot.eng_eid + ",detail information  please click http://econ.nxp.com/msg/" + str(another_msg.id) #fixme
        send_mail(msg.sender.member.Email, "Manager reject to scrap lot", content)

        record = Record(
            lots=msg.lot,
            qty=msg.lot.qty,
            comment=request.POST.get("scrap_comment"),
            PE=request.user,#requestor
            MC=request.user,#operator
            op="Stop",
            date=datetime.now(),
            purpose="NA",
        )
        record.save()

        msg.lot.status = "in"
        msg.lot.date = datetime.now()
        msg.lot.save()

    return HttpResponse("OK")

@csrf_exempt
def scrap_result(request):
    if request.user.member.role == "pe":
        return HttpResponse("FAILED! PE can not handle this.")
    if request.user.member.role == "manager":
        return HttpResponse("FAILED! Manager can not handle this.")
    msg_id = request.POST.get("id")
    msg = Msg.objects.get(id=msg_id)
    pe = User.objects.get(id=json.loads(msg.message).get("pe"))
    with transaction.atomic():
        record = Record(
            lots=msg.lot,
            qty=msg.lot.qty,
            comment="All scrapped.",
            PE=pe,#requestor
            MC=request.user,#operator
            op="scrap",
            date=datetime.now(),
            purpose="NA",
        )
        record.save()

        msg.lot.qty = 0
        msg.lot.status = "scrapped"
        msg.lot.date = datetime.now()
        msg.lot.save()

        msg.status = "done"
        msg.save()
        content = "MC finished scrap lot:" + msg.lot.eng_eid
        send_mail(pe.member.Email, "Finished scrap lot", content)
        return HttpResponse("OK")

@login_required
def msg_list(request):
    query = Q(receiver=request.user) | Q(receive_role=request.user.member.role)|Q(sender=request.user)

    if request.GET.get("status") and request.GET.get("status") != "all":
        status = request.GET.get("status")
        query = query & Q(status=request.GET.get("status"))
    elif request.GET.get("status") == "all":
        query = query
    else:
        if request.user.member.role == "mc":
            query = query & Q(status="mctodo")
        elif request.user.member.role == "manager":
            query = query & Q(status="managertodo")
    msgs = Msg.objects.filter(query).order_by("-id")
    return render(request, "lots/msg.html", locals())


@csrf_exempt
def add(request):
    if request.method == "POST":
        if request.user.member.role == "mc":
            msg = add_one_lot(request.POST, request.user)
            return HttpResponse(msg)
        else:
            return HttpResponse("FAILED! only MC can add.")

@csrf_exempt
def import_lots(request):
    if request.user.member.role == "mc":
        wb = xlrd.open_workbook(file_contents=request.FILES["file"].read())
        sheet = wb.sheets()[0]
        errors = []

        with transaction.atomic():
            for row in range(1,sheet.nrows):
                PE = User.objects.get(member__name=sheet.cell(row, 11).value)
                pe_username = PE.username
                msg = add_one_lot({
                    "mfg_eid":sheet.cell(row,0).value,
                    "eng_eid": gen_ENGID(request.user.username),
                    "LPN": sheet.cell(row,1).value,
                    "part_number": sheet.cell(row,2).value,
                    "package": sheet.cell(row, 3).value,
                    "tracecode": sheet.cell(row, 4).value,
                    "qty": sheet.cell(row, 5).value,
                    "purpose": sheet.cell(row, 6).value,
                    "box_number": sheet.cell(row, 7).value,
                    "source": sheet.cell(row, 8).value,
                    "shelf_number": sheet.cell(row, 9).value,
                    "shelf_code": sheet.cell(row, 10).value,
                    "PE": pe_username,
                }, request.user)
                if msg != "OK":
                    errors.append(msg)
        if len(errors):
            messages.info(request, "somthing went wrong:"+"\n".join(errors))
        else:
            messages.success(request, "all added.")

        return HttpResponseRedirect("/lots/")
    else:
        return HttpResponse("FAILED! only MC can add.")

def send_mail(receiver, subject, content):
    mail_host = "smtp.ap-rdc01.nxp.com"
    sender = 'ECON@nxp.com'# fixme
    message = content
    message = MIMEText(message, 'html', 'utf-8')
    message['Subject'] = Header(subject)
    message['To'] = Header(receiver)

    server = smtplib.SMTP()
    server.connect(mail_host)

    #Fixme now hand modify mc
    if receiver == "mc_group":
        mc_list= ["yang.liu21881@nxp.com","yu.pang@nxp.com"] #fixme
        for email in mc_list:
            server.sendmail(sender, email, message.as_string())


    else:
        server.sendmail(sender, receiver, message.as_string())
    server.quit()




@csrf_exempt
def generate_ENGID(request):
    ENGID = gen_ENGID(request.user.username)
    return HttpResponse(ENGID)





