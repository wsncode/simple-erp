# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import datetime


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('lots', '0002_auto_20171126_1626'),
    ]

    operations = [
        migrations.CreateModel(
            name='Msg',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('date', models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 39, 47, 904825))),
                ('op', models.CharField(max_length=10)),
                ('status', models.CharField(max_length=10)),
            ],
        ),
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 39, 47, 903823)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 11, 26, 20, 39, 47, 904324)),
        ),
        migrations.AddField(
            model_name='msg',
            name='lot',
            field=models.ForeignKey(to='lots.Lots'),
        ),
        migrations.AddField(
            model_name='msg',
            name='receiver',
            field=models.ForeignKey(related_name='msg_receiver', to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name='msg',
            name='sender',
            field=models.ForeignKey(related_name='msg_sender', to=settings.AUTH_USER_MODEL),
        ),
    ]
