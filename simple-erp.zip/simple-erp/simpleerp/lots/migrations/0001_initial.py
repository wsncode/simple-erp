# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Lots',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('mfg_eid', models.CharField(max_length=50, blank=True, null=True)),
                ('eng_eid', models.CharField(max_length=50)),
                ('LPN', models.CharField(max_length=50)),
                ('part_number', models.CharField(max_length=50)),
                ('package', models.CharField(max_length=15)),
                ('tracecode', models.CharField(max_length=50, blank=True, null=True)),
                ('qty', models.IntegerField()),
                ('purpose', models.CharField(max_length=100)),
                ('shelf_number', models.CharField(max_length=10)),
                ('box_number', models.CharField(max_length=10)),
                ('source', models.CharField(max_length=10)),
                ('date', models.DateTimeField(default=datetime.datetime(2017, 11, 26, 16, 23, 18, 484111))),
                ('status', models.CharField(max_length=10, choices=[('wip', 'Current WIP'), ('scraped', 'Scraped Material')])),
                ('PE', models.ForeignKey(related_name='current_PE', to=settings.AUTH_USER_MODEL)),
                ('manager', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
            ],
        ),
        migrations.CreateModel(
            name='Record',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('qty', models.IntegerField()),
                ('comment', models.CharField(max_length=100)),
                ('date', models.DateTimeField(default=datetime.datetime(2017, 11, 26, 16, 23, 18, 485114))),
                ('op', models.CharField(max_length=10, choices=[('take', 'take'), ('return', 'return'), ('scrap', 'scrap'), ('split', 'split'), ('merge', 'merge'), ('new', 'new')])),
                ('purpose', models.CharField(max_length=100)),
                ('MC', models.ForeignKey(related_name='MC', to=settings.AUTH_USER_MODEL)),
                ('PE', models.ForeignKey(to=settings.AUTH_USER_MODEL)),
                ('lots', models.ForeignKey(to='lots.Lots')),
            ],
        ),
    ]
