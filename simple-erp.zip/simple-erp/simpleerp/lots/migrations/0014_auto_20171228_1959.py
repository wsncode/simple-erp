# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('lots', '0013_auto_20171217_2142'),
    ]

    operations = [
        migrations.AlterField(
            model_name='lots',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 28, 19, 59, 27, 367109)),
        ),
        migrations.AlterField(
            model_name='lots',
            name='status',
            field=models.CharField(max_length=10, choices=[('in', 'In stock'), ('out', 'Out'), ('scrapped', 'Scrapped')]),
        ),
        migrations.AlterField(
            model_name='msg',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 28, 19, 59, 27, 367109)),
        ),
        migrations.AlterField(
            model_name='record',
            name='date',
            field=models.DateTimeField(default=datetime.datetime(2017, 12, 28, 19, 59, 27, 367109)),
        ),
        migrations.AlterField(
            model_name='record',
            name='op',
            field=models.CharField(max_length=10, choices=[('take', 'Take'), ('return', 'Return'), ('split', 'Split'), ('merge', 'Merge'), ('new', 'New'), ('scrap', 'Scrapped'), ('pending', 'Pending scrap'), ('Stop', 'Stop scrap')]),
        ),
    ]
