# -*- coding: utf-8 -*-
from django.contrib import admin
from .models import Lots, Record, Msg

admin.site.register(Lots)
admin.site.register(Record)
admin.site.register(Msg)
