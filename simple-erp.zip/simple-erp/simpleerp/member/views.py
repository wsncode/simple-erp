from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import HttpResponseRedirect, HttpResponse
from ldap3 import Server, Connection, ALL


# Create your views here.
@csrf_exempt
def userLogin(request):
    if request.method == "GET":
        return render(request, "member/login.html", locals())
    elif request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        special_list = ["mc0","mc1"]  # use special list to handle MC member #fixme
        label = 1
        for name in special_list:
            if username == name:
                user = authenticate(username=username, password=password)
                label = 0
        if label:
            try:
                result = authenticate_whoami(username, password)  # WBI
            except Exception:
                messages.warning(request, "User name not exist or password is wrong!!")
                return render(request, "member/login.html", locals())
            user = authenticate(username=username, password=username)

        if user is not None:
            if user.is_active:
                login(request, user)
                return HttpResponseRedirect("/lots/")
            else:
                messages.warning(request, "User name not exist or password is wrong!!")
                return render(request, "member/login.html", locals())
        else:
            messages.warning(request, "User name not exist or password is wrong!!")
            return render(request, "member/login.html", locals())


def userLogout(request):
    logout(request)
    messages.success(request,"Logout Successfully, thank you!")
    return HttpResponseRedirect("/login/")

def authenticate_whoami(username,password):
    server = Server('ldap://apac-dc.nxp.com:389', get_info=ALL)
    conn = Connection(server, 'CN='+username+',OU=Developers,OU=Managed Users,OU=CN,OU=NXP,DC=wbi,DC=nxp,DC=com',password, auto_bind=True)
    result = conn.extend.standard.who_am_i()
    return result
