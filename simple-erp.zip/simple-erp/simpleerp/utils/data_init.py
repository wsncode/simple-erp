import os, datetime
from django.core.wsgi import get_wsgi_application
from django.db import transaction

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "simpleerp.settings")
application = get_wsgi_application()

from lots.models import Lots
from lots.models import Record
from django.contrib.auth.models import User


@transaction.atomic
def read_csv():
    with open("2223.csv", encoding="utf-8") as fp:
        line = fp.readline() # 1st line no data
        for line in fp.readlines():
            line = line.split(";")
            with transaction.atomic():
                lot = Lots(**{
                    "mfg_eid":line[5],
                    "eng_eid":line[1],
                    "LPN":line[2],
                    "part_number":line[6],
                    "package":line[7],
                    "tracecode":line[8],
                    "qty":line[9],
                    "purpose":line[10],
                    "shelf_number":line[14],
                    "shelf_code":line[15],
                    "box_number":"1",
                    "source":"eng",
                    "date":datetime.datetime.strptime(line[12],'%m/%d/%Y'),
                    "PE":User.objects.get(member__name=line[3]),
                    "manager":User.objects.get(member__name=line[4]),
                    "status":"in"
                })
                lot.save()
                record = Record(**{
                    "lots":lot,
                    "package":line[7],
                    "qty":line[9],
                    "comment":"NA",
                    "PE":User.objects.get(member__name=line[3]),
                    "MC":User.objects.get(member__name="mc0_test"),
                    "date":datetime.datetime.strptime(line[12], '%m/%d/%Y'),
                    "purpose":"NA",
                    "op":"new"
                })
                record.save()



def undo():
    lots = Lots.objects.filter(date_joined__gt = (datetime.datetime.now()-datetime.timedelta(hours=1))).delete()


if __name__ == "__main__":
   read_csv()
