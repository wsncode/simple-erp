# -*- coding: utf-8 -*-

from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

import member.views as member_views
import lots.views as lots_views
import pages.views as pages_views

urlpatterns = [
    url(r'^admin/', include(admin.site.urls)),
    # url(r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.STATIC_ROOT}),

    url(r"^$", pages_views.index),
    url(r"^login/$", member_views.userLogin),
    url(r"^logout/$", member_views.userLogout),
    url(r"^record/(?P<eng_eid>.*)$", lots_views.record),
    url(r'^accounts/login/$', member_views.userLogin),

    # Lots
    url(r"^lots/$", lots_views.list),
    url(r"^lots/merge/$", lots_views.merge),
    url(r"^lots/edit/$", lots_views.edit),
    url(r"^lots/take/$", lots_views.take),
    url(r"^lots/add/$", lots_views.add),
    url(r"^lots/import/$", lots_views.import_lots),
    url(r"^lots/return/$", lots_views.lotreturn),
    url(r"^lots/split/$", lots_views.split),
    url(r"^lots/scrap_req/$", lots_views.scrap_req),
    url(r"^lots/scrap_result/$", lots_views.scrap_result),
    url(r"^lots/gen_eng_eid/$", lots_views.generate_ENGID),


    # msg
    url(r"^msg/$", lots_views.msg_list),
    url(r"^msg/handle/$", lots_views.msg_handle),
    url(r"^msg/approve/$", lots_views.pm_approve),
    url(r"^msg/reject/$", lots_views.pm_reject),
    url(r"^msg/(?P<msg_id>\d+)$", lots_views.msg_detail),

    # POST
    url(r"^ac/$", pages_views.ac),

    #Export
    url(r"^export/record/(?P<eng_eid>.*)$", lots_views.record_export_exl),
    url(r"^export/lots/$", lots_views.lots_export_exl),

]
